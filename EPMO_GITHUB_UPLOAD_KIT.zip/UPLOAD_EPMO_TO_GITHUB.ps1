# EPMO source transfer — run locally in PowerShell (Windows)
# Requires Git (https://git-scm.com/downloads) and an interactive GitHub login.
$ErrorActionPreference = 'Stop'
$repo = 'https://github.com/faisalwrokksa-hub/THEEPMOTEST.git'
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$zip = Join-Path $here 'the-epmo-safe-source.zip'
$target = Join-Path $here 'THEEPMOTEST-upload'
if (!(Get-Command git -ErrorAction SilentlyContinue)) { throw 'Git is not installed. Install Git for Windows first.' }
if (!(Test-Path $zip)) { throw 'Missing the-epmo-safe-source.zip beside this script.' }
if (Test-Path $target) { throw 'THEEPMOTEST-upload already exists. Review it instead of overwriting.' }
New-Item -ItemType Directory -Path $target | Out-Null
Expand-Archive -LiteralPath $zip -DestinationPath $target -Force
Set-Location $target
if (!(Test-Path '.github/workflows/ci.yml')) { throw 'CI workflow is missing; aborting.' }
if (!(Test-Path 'pnpm-lock.yaml')) { throw 'Lockfile is missing; aborting.' }
@'
.env
.env.*
!.env.example
!.env.*.example
node_modules/
.next/
*.pem
*.p12
*.pfx
*.key
'@ | Add-Content -Path '.gitignore'
# Do not overwrite a repo that has received content since verification.
$remote = git ls-remote $repo HEAD 2>&1
if ($LASTEXITCODE -ne 0) { throw "Cannot access repository. Authenticate via Git Credential Manager, then retry. $remote" }
if ($remote) { throw 'Remote repository is no longer empty. Stop and reconcile the existing branch first.' }
git init -b main
if ($LASTEXITCODE -ne 0) { throw 'git init failed' }
git remote add origin $repo
git add .
$staged = git diff --cached --name-only
if ($staged -match '(^|/)(\.env\.prod|\.env\.staging|\.env\.local|node_modules|\.next)(/|$)') { throw 'Sensitive or generated files staged; aborting.' }
git commit -m 'Import EPMO Checkpoint 30 for P0 acceptance CI'
if ($LASTEXITCODE -ne 0) { throw 'Commit failed. Configure git user.name/email if needed.' }
git push -u origin main
if ($LASTEXITCODE -ne 0) { throw 'Git push failed. Check your GitHub sign-in and repository permissions.' }
Write-Host 'Upload complete. View CI at https://github.com/faisalwrokksa-hub/THEEPMOTEST/actions'
